﻿/*
 * Created by SharpDevelop.
 * User: isaac JR
 * Date: 08/10/2025
 * Time: 18:23
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace trabalho
{
	partial class MainForm
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			this.menuStrip2 = new System.Windows.Forms.MenuStrip();
			this.qUESTÃO1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.qUESTÃO2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.qUESTÃO3ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.qUESTÃO4ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.qUESTÃO5ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.qUESTÃO6ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.qUESTÃO7ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.qUESTÃO8ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.qUESTÃO9ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.qUESTÃO10ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.menuStrip1 = new System.Windows.Forms.MenuStrip();
			this.iNICIARToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.sAIRToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.button1 = new System.Windows.Forms.Button();
			this.button2 = new System.Windows.Forms.Button();
			this.button3 = new System.Windows.Forms.Button();
			this.button4 = new System.Windows.Forms.Button();
			this.menuStrip2.SuspendLayout();
			this.menuStrip1.SuspendLayout();
			this.SuspendLayout();
			// 
			// menuStrip2
			// 
			this.menuStrip2.BackColor = System.Drawing.Color.Firebrick;
			this.menuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
									this.qUESTÃO1ToolStripMenuItem,
									this.qUESTÃO2ToolStripMenuItem,
									this.qUESTÃO3ToolStripMenuItem,
									this.qUESTÃO4ToolStripMenuItem,
									this.qUESTÃO5ToolStripMenuItem,
									this.qUESTÃO6ToolStripMenuItem,
									this.qUESTÃO7ToolStripMenuItem,
									this.qUESTÃO8ToolStripMenuItem,
									this.qUESTÃO9ToolStripMenuItem,
									this.qUESTÃO10ToolStripMenuItem});
			this.menuStrip2.Location = new System.Drawing.Point(0, 24);
			this.menuStrip2.Name = "menuStrip2";
			this.menuStrip2.Size = new System.Drawing.Size(818, 24);
			this.menuStrip2.TabIndex = 0;
			this.menuStrip2.Text = "menuStrip2";
			this.menuStrip2.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.MenuStrip2ItemClicked);
			// 
			// qUESTÃO1ToolStripMenuItem
			// 
			this.qUESTÃO1ToolStripMenuItem.Name = "qUESTÃO1ToolStripMenuItem";
			this.qUESTÃO1ToolStripMenuItem.Size = new System.Drawing.Size(80, 20);
			this.qUESTÃO1ToolStripMenuItem.Text = "QUESTÃO 1";
			this.qUESTÃO1ToolStripMenuItem.Click += new System.EventHandler(this.QUESTÃO1ToolStripMenuItemClick);
			// 
			// qUESTÃO2ToolStripMenuItem
			// 
			this.qUESTÃO2ToolStripMenuItem.Name = "qUESTÃO2ToolStripMenuItem";
			this.qUESTÃO2ToolStripMenuItem.Size = new System.Drawing.Size(80, 20);
			this.qUESTÃO2ToolStripMenuItem.Text = "QUESTÃO 2";
			this.qUESTÃO2ToolStripMenuItem.Click += new System.EventHandler(this.QUESTÃO2ToolStripMenuItemClick);
			// 
			// qUESTÃO3ToolStripMenuItem
			// 
			this.qUESTÃO3ToolStripMenuItem.Name = "qUESTÃO3ToolStripMenuItem";
			this.qUESTÃO3ToolStripMenuItem.Size = new System.Drawing.Size(80, 20);
			this.qUESTÃO3ToolStripMenuItem.Text = "QUESTÃO 3";
			this.qUESTÃO3ToolStripMenuItem.Click += new System.EventHandler(this.QUESTÃO3ToolStripMenuItemClick);
			// 
			// qUESTÃO4ToolStripMenuItem
			// 
			this.qUESTÃO4ToolStripMenuItem.Name = "qUESTÃO4ToolStripMenuItem";
			this.qUESTÃO4ToolStripMenuItem.Size = new System.Drawing.Size(80, 20);
			this.qUESTÃO4ToolStripMenuItem.Text = "QUESTÃO 4";
			this.qUESTÃO4ToolStripMenuItem.Click += new System.EventHandler(this.QUESTÃO4ToolStripMenuItemClick);
			// 
			// qUESTÃO5ToolStripMenuItem
			// 
			this.qUESTÃO5ToolStripMenuItem.Name = "qUESTÃO5ToolStripMenuItem";
			this.qUESTÃO5ToolStripMenuItem.Size = new System.Drawing.Size(80, 20);
			this.qUESTÃO5ToolStripMenuItem.Text = "QUESTÃO 5";
			this.qUESTÃO5ToolStripMenuItem.Click += new System.EventHandler(this.QUESTÃO5ToolStripMenuItemClick);
			// 
			// qUESTÃO6ToolStripMenuItem
			// 
			this.qUESTÃO6ToolStripMenuItem.Name = "qUESTÃO6ToolStripMenuItem";
			this.qUESTÃO6ToolStripMenuItem.Size = new System.Drawing.Size(80, 20);
			this.qUESTÃO6ToolStripMenuItem.Text = "QUESTÃO 6";
			this.qUESTÃO6ToolStripMenuItem.Click += new System.EventHandler(this.QUESTÃO6ToolStripMenuItemClick);
			// 
			// qUESTÃO7ToolStripMenuItem
			// 
			this.qUESTÃO7ToolStripMenuItem.Name = "qUESTÃO7ToolStripMenuItem";
			this.qUESTÃO7ToolStripMenuItem.Size = new System.Drawing.Size(80, 20);
			this.qUESTÃO7ToolStripMenuItem.Text = "QUESTÃO 7";
			this.qUESTÃO7ToolStripMenuItem.Click += new System.EventHandler(this.QUESTÃO7ToolStripMenuItemClick);
			// 
			// qUESTÃO8ToolStripMenuItem
			// 
			this.qUESTÃO8ToolStripMenuItem.BackColor = System.Drawing.Color.Firebrick;
			this.qUESTÃO8ToolStripMenuItem.Name = "qUESTÃO8ToolStripMenuItem";
			this.qUESTÃO8ToolStripMenuItem.Size = new System.Drawing.Size(80, 20);
			this.qUESTÃO8ToolStripMenuItem.Text = "QUESTÃO 8";
			this.qUESTÃO8ToolStripMenuItem.Click += new System.EventHandler(this.QUESTÃO8ToolStripMenuItemClick);
			// 
			// qUESTÃO9ToolStripMenuItem
			// 
			this.qUESTÃO9ToolStripMenuItem.Name = "qUESTÃO9ToolStripMenuItem";
			this.qUESTÃO9ToolStripMenuItem.Size = new System.Drawing.Size(80, 20);
			this.qUESTÃO9ToolStripMenuItem.Text = "QUESTÃO 9";
			this.qUESTÃO9ToolStripMenuItem.Click += new System.EventHandler(this.QUESTÃO9ToolStripMenuItemClick);
			// 
			// qUESTÃO10ToolStripMenuItem
			// 
			this.qUESTÃO10ToolStripMenuItem.Name = "qUESTÃO10ToolStripMenuItem";
			this.qUESTÃO10ToolStripMenuItem.Size = new System.Drawing.Size(86, 20);
			this.qUESTÃO10ToolStripMenuItem.Text = "QUESTÃO 10";
			this.qUESTÃO10ToolStripMenuItem.Click += new System.EventHandler(this.QUESTÃO10ToolStripMenuItemClick);
			// 
			// menuStrip1
			// 
			this.menuStrip1.BackColor = System.Drawing.Color.Firebrick;
			this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
									this.iNICIARToolStripMenuItem,
									this.sAIRToolStripMenuItem});
			this.menuStrip1.Location = new System.Drawing.Point(0, 0);
			this.menuStrip1.Name = "menuStrip1";
			this.menuStrip1.Size = new System.Drawing.Size(818, 24);
			this.menuStrip1.TabIndex = 1;
			this.menuStrip1.Text = "menuStrip1";
			// 
			// iNICIARToolStripMenuItem
			// 
			this.iNICIARToolStripMenuItem.Name = "iNICIARToolStripMenuItem";
			this.iNICIARToolStripMenuItem.Size = new System.Drawing.Size(60, 20);
			this.iNICIARToolStripMenuItem.Text = "INICIAR";
			// 
			// sAIRToolStripMenuItem
			// 
			this.sAIRToolStripMenuItem.Name = "sAIRToolStripMenuItem";
			this.sAIRToolStripMenuItem.Size = new System.Drawing.Size(43, 20);
			this.sAIRToolStripMenuItem.Text = "SAIR";
			this.sAIRToolStripMenuItem.Click += new System.EventHandler(this.SAIRToolStripMenuItemClick);
			// 
			// label1
			// 
			this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.25F);
			this.label1.Location = new System.Drawing.Point(13, 76);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(793, 55);
			this.label1.TabIndex = 2;
			this.label1.Text = "1. Matemática – Álgebra";
			// 
			// label2
			// 
			this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
			this.label2.Location = new System.Drawing.Point(13, 131);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(513, 107);
			this.label2.TabIndex = 3;
			this.label2.Text = "Resolva a equação: 2x+5=13";
			this.label2.Click += new System.EventHandler(this.Label2Click);
			// 
			// button1
			// 
			this.button1.BackColor = System.Drawing.Color.IndianRed;
			this.button1.Location = new System.Drawing.Point(12, 241);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(313, 38);
			this.button1.TabIndex = 4;
			this.button1.Text = "A) 4";
			this.button1.UseVisualStyleBackColor = false;
			this.button1.Click += new System.EventHandler(this.Button1Click);
			// 
			// button2
			// 
			this.button2.BackColor = System.Drawing.Color.IndianRed;
			this.button2.Location = new System.Drawing.Point(13, 285);
			this.button2.Name = "button2";
			this.button2.Size = new System.Drawing.Size(312, 36);
			this.button2.TabIndex = 5;
			this.button2.Text = "B) 5";
			this.button2.UseVisualStyleBackColor = false;
			this.button2.Click += new System.EventHandler(this.Button2Click);
			// 
			// button3
			// 
			this.button3.BackColor = System.Drawing.Color.IndianRed;
			this.button3.Location = new System.Drawing.Point(13, 327);
			this.button3.Name = "button3";
			this.button3.Size = new System.Drawing.Size(312, 36);
			this.button3.TabIndex = 6;
			this.button3.Text = "C) 6";
			this.button3.UseVisualStyleBackColor = false;
			this.button3.Click += new System.EventHandler(this.Button3Click);
			// 
			// button4
			// 
			this.button4.BackColor = System.Drawing.Color.IndianRed;
			this.button4.Location = new System.Drawing.Point(13, 369);
			this.button4.Name = "button4";
			this.button4.Size = new System.Drawing.Size(312, 39);
			this.button4.TabIndex = 7;
			this.button4.Text = "D) 8";
			this.button4.UseVisualStyleBackColor = false;
			this.button4.Click += new System.EventHandler(this.Button4Click);
			// 
			// MainForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.MistyRose;
			this.ClientSize = new System.Drawing.Size(818, 477);
			this.Controls.Add(this.button4);
			this.Controls.Add(this.button3);
			this.Controls.Add(this.button2);
			this.Controls.Add(this.button1);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.menuStrip2);
			this.Controls.Add(this.menuStrip1);
			this.Name = "MainForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "trabalho";
			this.TransparencyKey = System.Drawing.Color.Transparent;
			this.menuStrip2.ResumeLayout(false);
			this.menuStrip2.PerformLayout();
			this.menuStrip1.ResumeLayout(false);
			this.menuStrip1.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();
		}
		private System.Windows.Forms.Button button4;
		private System.Windows.Forms.Button button3;
		private System.Windows.Forms.Button button2;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.ToolStripMenuItem qUESTÃO10ToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem qUESTÃO9ToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem qUESTÃO8ToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem qUESTÃO7ToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem qUESTÃO6ToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem qUESTÃO5ToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem qUESTÃO4ToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem qUESTÃO3ToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem qUESTÃO2ToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem qUESTÃO1ToolStripMenuItem;
		private System.Windows.Forms.MenuStrip menuStrip2;
		private System.Windows.Forms.ToolStripMenuItem sAIRToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem iNICIARToolStripMenuItem;
		private System.Windows.Forms.MenuStrip menuStrip1;
	}
}
