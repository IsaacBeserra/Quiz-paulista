﻿/*
 * Created by SharpDevelop.
 * User: isaac JR
 * Date: 08/10/2025
 * Time: 18:23
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace trabalho
{
	/// <summary>
	/// Description of MainForm.
	/// </summary>
	public partial class MainForm : Form
	{
		public MainForm()
		{
			
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		
		public static int ponto = 0;
		public static bool q1 = true, q2 = true, q3 = true, q4 = true, q5 = true, q6 = true, q7 = true, q8 = true, q9 = true, q10 = true;
		
		void Button1Click(object sender, EventArgs e)
		{
			if (button1.Text == "A) 4")
			{
				if (q1 == true)
				{
					MessageBox.Show("acertou!");
					label1.Text = "2. Matemática – Geometria";
             	    label2.Text = "Um triângulo tem lados 3 cm, 4 cm e 5 cm. Qual é a área?";
            	    button1.Text = "A) 6 cm²";
                    button2.Text = "B) 7 cm²";
             	    button3.Text = "C) 5 cm²";
                    button4.Text = "D) 12 cm²";
                    ponto = ponto + 1;
                    q1 = false;
				}
			}
			else if (button1.Text == "A) 6 cm²")
			{
				if (q2 == true)
				{
			    	MessageBox.Show("acertou!");
		    		label1.Text = "3. Português – Interpretação de Texto";
                    label2.Text = "Leia: “O sol se pôs no horizonte, tingindo o céu de laranja.”" +
                	    "O verbo “tingindo” indica:";
                    button1.Text = "A) Ação passada concluída";
                    button2.Text = "B) Ação contínua";
                    button3.Text = "C) Ação futura";
                    button4.Text = "D) Ação condicional";
                    ponto = ponto + 1;
                    q2 = false;
				}
			}
			else if (button1.Text == "A) Ação passada concluída")
			{
				if (q3 == true)
				{
			    	MessageBox.Show("errou!");
		        	label1.Text = "4. Português – Gramática";
                    label2.Text = "Qual frase está correta?";
                    button1.Text = "A) Eu vou à escola todos os dias.";
                    button2.Text = "B) Eu vou a escola todos os dias.";
                    button3.Text = "C) Eu vou à escola todos os dia.";
                    button4.Text = "D) Eu vou a escola todos os dia.";
				}
			}
			else if (button1.Text == "A) Eu vou à escola todos os dias.")
			{
				if (q4 == true)
				{
			    	MessageBox.Show("acertou!");
			    	label1.Text = "5. História – Brasil Colônia";
                    label2.Text = "Qual atividade econômica foi a base da economia do Brasil colonial no século XVI?";
                    button1.Text = "A) Mineração";
                    button2.Text = "B) Pecuária";
                    button3.Text = "C) Agricultura de cana-de-açúcar";
                    button4.Text = "D) Industrialização";
                    ponto = ponto + 1;
                    q4 = false;
				}
			}
			else if (button1.Text == "A) Mineração")
			{
				if (q5 == true)
				{
			    	MessageBox.Show("errou!");
			    	label1.Text = "6. História – Brasil Império";
                    label2.Text = "Quem proclamou a Independência do Brasil?";
                    button1.Text = "A) Dom Pedro I";
                    button2.Text = "B) Tiradentes";
                    button3.Text = "C) Dom João VI";
                    button4.Text = "D) Marechal Deodoro";
				}
			}
			else if (button1.Text == "A) Dom Pedro I")
			{
				if (q6 == true)
				{
		    		MessageBox.Show("acertou!");
			    	label1.Text = "7. Geografia – Meio Ambiente";
                    label2.Text = "O que é desmatamento?";
                    button1.Text = "A) Plantio de árvores em áreas urbanas";
                    button2.Text = "B) Corte ou remoção da vegetação natural";
                    button3.Text = "C) Proteção de áreas florestais";
                    button4.Text = "D) Erosão do solo natural";
                    ponto = ponto + 1;
                    q6 = false;
				}
			}
			else if (button1.Text == "A) Plantio de árvores em áreas urbanas")
			{
				if (q7 == true)
				{
			    	MessageBox.Show("errou!");
				    label1.Text = "8. Geografia – Clima";
                    label2.Text = "Qual clima é predominante no estado de São Paulo?";
                    button1.Text = "A) tropical";
                    button2.Text = "B) equatorial";
                    button3.Text = "C) Semiárido";
                    button4.Text = "D) Polar";
				}
			}
			else if (button1.Text == "A) tropical")
			{
				if (q8 == true)
				{
			    	MessageBox.Show("acertou!");
				    label1.Text = "9. Ciências – Física";
                    label2.Text = "Um objeto de 2 kg é empurrado com força de 10 N. Qual a aceleração (em m/s²)?" +
                	"F=m⋅a";
                    button1.Text = "A) 2";
                    button2.Text = "B) 5";
                    button3.Text = "C) 10";
                    button4.Text = "D) 20";
                    ponto = ponto + 1;
                    q8 = false;
				}
			}
			else if (button1.Text == "A) 2")
			{
				if (q9 == true)
				{
				     MessageBox.Show("errou!");
			        label1.Text = "10. Ciências – Biologia";
 			        label2.Text = "Qual é a função principal dos glóbulos vermelhos?";
 			        button1.Text = "A) Combater infecções";
 		    	    button2.Text = "B) Transportar oxigênio";
 			        button3.Text = "C) Produzir hormônios";
 		    	    button4.Text = "D) Digestão de nutrientes";
				}
			}
			else if (button1.Text == "A) Combater infecções")
			{
			    MessageBox.Show("errou!");
			    Form telafinal = new tela_final();
		        telafinal.Show();
		    	this.Hide();
			}
		}
		
		void Button2Click(object sender, EventArgs e)
		{
			if (button2.Text == "B) 9")
			{
				MessageBox.Show("errou!");
    			label1.Text = "2. Matemática – Geometria";
                label2.Text = "Um triângulo tem lados 3 cm, 4 cm e 5 cm. Qual é a área?";
                button1.Text = "A) 6 cm²";
                button2.Text = "B) 7 cm²";
                button3.Text = "C) 5 cm²";
                button4.Text = "D) 12 cm²";
			}
			else if (button2.Text == "B) 7 cm²")
			{
				MessageBox.Show("errou!");
				label1.Text = "3. Português – Interpretação de Texto";
                label2.Text = "Leia: “O sol se pôs no horizonte, tingindo o céu de laranja.”" +
            	    "O verbo “tingindo” indica:";
                button1.Text = "A) Ação passada concluída";
                button2.Text = "B) Ação contínua";
                button3.Text = "C) Ação futura";
                button4.Text = "D) Ação condicional";
			}
			else if (button2.Text == "B) Ação contínua")
			{
				MessageBox.Show("acertou!");
				label1.Text = "4. Português – Gramática";
                label2.Text = "Qual frase está correta?";
                button1.Text = "A) Eu vou à escola todos os dias.";
                button2.Text = "B) Eu vou a escola todos os dias.";
                button3.Text = "C) Eu vou à escola todos os dia.";
                button4.Text = "D) Eu vou a escola todos os dia.";
                ponto = ponto + 1;
                q3 = false;
			}
			else if (button2.Text == "B) Eu vou a escola todos os dias.")
			{
				MessageBox.Show("errou!");
				label1.Text = "5. História – Brasil Colônia";
                label2.Text = "Qual atividade econômica foi a base da economia do Brasil colonial no século XVI?";
                button1.Text = "A) Mineração";
                button2.Text = "B) Pecuária";
                button3.Text = "C) Agricultura de cana-de-açúcar";
                button4.Text = "D) Industrialização";
			}
			else if (button2.Text == "B) Pecuária")
			{
				MessageBox.Show("errou!");
				label1.Text = "6. História – Brasil Império";
                label2.Text = "Quem proclamou a Independência do Brasil?";
                button1.Text = "A) Dom Pedro I";
                button2.Text = "B) Tiradentes";
                button3.Text = "C) Dom João VI";
                button4.Text = "D) Marechal Deodoro";
			}
			else if (button2.Text == "B) Tiradentes")
			{
				MessageBox.Show("errou!");
				label1.Text = "7. Geografia – Meio Ambiente";
                label2.Text = "O que é desmatamento?";
                button1.Text = "A) Plantio de árvores em áreas urbanas";
                button2.Text = "B) Corte ou remoção da vegetação natural";
                button3.Text = "C) Proteção de áreas florestais";
                button4.Text = "D) Erosão do solo natural";
			}
			else if (button2.Text == "B) Corte ou remoção da vegetação natural")
			{
				MessageBox.Show("acertou!");
				label1.Text = "8. Geografia – Clima";
                label2.Text = "Qual clima é predominante no estado de São Paulo?";
                button1.Text = "A) tropical";
                button2.Text = "B) equatorial";
                button3.Text = "C) Semiárido";
                button4.Text = "D) Polar";
                ponto = ponto + 1;
                q7 = false;
			}
			else if (button2.Text == "B) equatorial")
			{
				MessageBox.Show("errou!");
				label1.Text = "9. Ciências – Física";
                label2.Text = "Um objeto de 2 kg é empurrado com força de 10 N. Qual a aceleração (em m/s²)?" +
            	"F=m⋅a";
                button1.Text = "A) 2";
                button2.Text = "B) 5";
                button3.Text = "C) 10";
                button4.Text = "D) 20";
			}
			else if (button2.Text == "B) 5")
			{
 			    MessageBox.Show("acertou!");
 			    label1.Text = "10. Ciências – Biologia";
 			    label2.Text = "Qual é a função principal dos glóbulos vermelhos?";
 			    button1.Text = "A) Combater infecções";
 			    button2.Text = "B) Transportar oxigênio";
 			    button3.Text = "C) Produzir hormônios";
 			    button4.Text = "D) Digestão de nutrientes";
 			    ponto = ponto + 1;
                q9 = false;
			}
			else if (button2.Text == "B) Transportar oxigênio")
			{
		        MessageBox.Show("acertou!");
		        ponto = ponto + 1;
                q10 = false;
 			    Form telafinal = new tela_final();
		    	telafinal.Show();
		    	this.Hide();
			}

		}
		
		void Button3Click(object sender, EventArgs e)
		{
			if (button3.Text == "C) 6")
			{
				MessageBox.Show("errou!");
		    	label1.Text = "1. Matemática – Álgebra";
                label2.Text = "Resolva a equação:" +
                	"2x+5=13";
                button1.Text = "A) 4";
                button2.Text = "B) 9";
                button3.Text = "C) 6";
                button4.Text = "D) 8";
			}
			else if (button3.Text == "C) 5 cm²")
			{
				MessageBox.Show("errou!");
				label1.Text = "3. Português – Interpretação de Texto";
                label2.Text = "Leia: “O sol se pôs no horizonte, tingindo o céu de laranja.”" +
            	    "O verbo “tingindo” indica:";
                button1.Text = "A) Ação passada concluída";
                button2.Text = "B) Ação contínua";
                button3.Text = "C) Ação futura";
                button4.Text = "D) Ação condicional";
			}
			else if (button3.Text == "C) Ação futura")
			{
				MessageBox.Show("errou!");
		    	label1.Text = "4. Português – Gramática";
                label2.Text = "Qual frase está correta?";
                button1.Text = "A) Eu vou à escola todos os dias.";
                button2.Text = "B) Eu vou a escola todos os dias.";
                button3.Text = "C) Eu vou à escola todos os dia.";
                button4.Text = "D) Eu vou a escola todos os dia.";
			}
			else if (button3.Text == "C) Eu vou à escola todos os dia.")
			{
				MessageBox.Show("errou!");
				label1.Text = "5. História – Brasil Colônia";
                label2.Text = "Qual atividade econômica foi a base da economia do Brasil colonial no século XVI?";
                button1.Text = "A) Mineração";
                button2.Text = "B) Pecuária";
                button3.Text = "C) Agricultura de cana-de-açúcar";
                button4.Text = "D) Industrialização";
			}
			else if (button3.Text == "C) Agricultura de cana-de-açúcar"){
				MessageBox.Show("acertou!");
				label1.Text = "6. História – Brasil Império";
                label2.Text = "Quem proclamou a Independência do Brasil?";
                button1.Text = "A) Dom Pedro I";
                button2.Text = "B) Tiradentes";
                button3.Text = "C) Dom João VI";
                button4.Text = "D) Marechal Deodoro";
                ponto = ponto + 1;
                q5 = false;
			}
			else if (button3.Text == "C) Dom João VI")
			{
				MessageBox.Show("errou!");
				label1.Text = "7. Geografia – Meio Ambiente";
                label2.Text = "O que é desmatamento?";
                button1.Text = "A) Plantio de árvores em áreas urbanas";
                button2.Text = "B) Corte ou remoção da vegetação natural";
                button3.Text = "C) Proteção de áreas florestais";
                button4.Text = "D) Erosão do solo natural";
			}
			else if (button3.Text == "C) Proteção de áreas florestais")
			{
				MessageBox.Show("errou!");
				label1.Text = "8. Geografia – Clima";
                label2.Text = "Qual clima é predominante no estado de São Paulo?";
                button1.Text = "A) tropical";
                button2.Text = "B) equatorial";
                button3.Text = "C) Semiárido";
                button4.Text = "D) Polar";
			}
			else if (button3.Text == "C) Proteção de áreas florestais")
			{
				MessageBox.Show("errou!");
				label1.Text = "9. Ciências – Física";
                label2.Text = "Um objeto de 2 kg é empurrado com força de 10 N. Qual a aceleração (em m/s²)?" +
            	"F=m⋅a";
                button1.Text = "A) 2";
                button2.Text = "B) 5";
                button3.Text = "C) 10";
                button4.Text = "D) 20";
			}
			else if (button3.Text == "C) 10")
			{
				MessageBox.Show("errou!");
				label1.Text = "10. Ciências – Biologia";
          	    label2.Text = "Qual é a função principal dos glóbulos vermelhos?";
        	    button1.Text = "A) Combater infecções";
          		button2.Text = "B) Transportar oxigênio";
          		button3.Text = "C) Produzir hormônios";
          		button4.Text = "D) Digestão de nutrientes";
			}
			else if (button3.Text == "C) Produzir hormônios")
			{
				MessageBox.Show("errou!");
		    	Form telafinal = new tela_final();
		    	telafinal.Show();
		    	this.Hide();
			}
		}
		
		void Button4Click(object sender, EventArgs e)
		{
			if (button4.Text == "D) 8")
			{
				MessageBox.Show("errou!");
			    label1.Text = "1. Matemática – Álgebra";
                label2.Text = "Resolva a equação:" +
                	"2x+5=13";
                button1.Text = "A) 4";
                button2.Text = "B) 9";
                button3.Text = "C) 6";
                button4.Text = "D) 8";
			}
			else if (button4.Text == "D) 12 cm²")
			{
				MessageBox.Show("errou!");
				label1.Text = "3. Português – Interpretação de Texto";
                label2.Text = "Leia: “O sol se pôs no horizonte, tingindo o céu de laranja.”" +
            	    "O verbo “tingindo” indica:";
                button1.Text = "A) Ação passada concluída";
                button2.Text = "B) Ação contínua";
                button3.Text = "C) Ação futura";
                button4.Text = "D) Ação condicional";
			}
			else if (button4.Text == "D) Ação condicional")
			{
				MessageBox.Show("errou!");
				label1.Text = "4. Português – Gramática";
                label2.Text = "Qual frase está correta?";
                button1.Text = "A) Eu vou à escola todos os dias.";
                button2.Text = "B) Eu vou a escola todos os dias.";
                button3.Text = "C) Eu vou à escola todos os dia.";
                button4.Text = "D) Eu vou a escola todos os dia.";
			}
			else if (button4.Text == "D) Eu vou a escola todos os dia.")
			{
				MessageBox.Show("errou!");
				label1.Text = "5. História – Brasil Colônia";
                label2.Text = "Qual atividade econômica foi a base da economia do Brasil colonial no século XVI?";
                button1.Text = "A) Mineração";
                button2.Text = "B) Pecuária";
                button3.Text = "C) Agricultura de cana-de-açúcar";
                button4.Text = "D) Industrialização";
			}
			else if (button4.Text == "D) Industrialização"){
				MessageBox.Show("errou!");
				label1.Text = "6. História – Brasil Império";
            label2.Text = "Quem proclamou a Independência do Brasil?";
            button1.Text = "A) Dom Pedro I";
            button2.Text = "B) Tiradentes";
            button3.Text = "C) Dom João VI";
            button4.Text = "D) Marechal Deodoro";
			}
			else if (button4.Text == "D) Marechal Deodoro")
			{
				MessageBox.Show("errou!");
				label1.Text = "7. Geografia – Meio Ambiente";
                label2.Text = "O que é desmatamento?";
                button1.Text = "A) Plantio de árvores em áreas urbanas";
                button2.Text = "B) Corte ou remoção da vegetação natural";
                button3.Text = "C) Proteção de áreas florestais";
                button4.Text = "D) Erosão do solo natural";
			}
			else if (button4.Text == "D) Erosão do solo natural")
			{
				MessageBox.Show("errou!");
				label1.Text = "8. Geografia – Clima";
                label2.Text = "Qual clima é predominante no estado de São Paulo?";
                button1.Text = "A) tropical";
                button2.Text = "B) equatorial";
                button3.Text = "C) Semiárido";
                button4.Text = "D) Polar";
			}
			else if (button4.Text == "D) Polar")
			{
				MessageBox.Show("errou!");
				label1.Text = "9. Ciências – Física";
                label2.Text = "Um objeto de 2 kg é empurrado com força de 10 N. Qual a aceleração (em m/s²)?" +
            	"F=m⋅a";
                button1.Text = "A) 2";
                button2.Text = "B) 5";
                button3.Text = "C) 10";
                button4.Text = "D) 20";
			}
			else if (button4.Text == "D) 20")
			{
				MessageBox.Show("errou!");
				label1.Text = "10. Ciências – Biologia";
          	    label2.Text = "Qual é a função principal dos glóbulos vermelhos?";
        	    button1.Text = "A) Combater infecções";
          		button2.Text = "B) Transportar oxigênio";
          		button3.Text = "C) Produzir hormônios";
          		button4.Text = "D) Digestão de nutrientes";
			}
			else if (button4.Text == "D) Digestão de nutrientes")
			{
				MessageBox.Show("errou!");
		    	Form telafinal = new tela_final();
		    	telafinal.Show();
		    	this.Hide();
			}
		}
		
		void QUESTÃO1ToolStripMenuItemClick(object sender, EventArgs e)
		{
			label1.Text = "1. Matemática – Álgebra";
            label2.Text = "Resolva a equação:" +
            	"2x+5=13";
            button1.Text = "A) 4";
            button2.Text = "B) 9";
            button3.Text = "C) 6";
            button4.Text = "D) 8";
		}
		
		void QUESTÃO2ToolStripMenuItemClick(object sender, EventArgs e)
		{
			label1.Text = "2. Matemática – Geometria";
            label2.Text = "Um triângulo tem lados 3 cm, 4 cm e 5 cm. Qual é a área?";
            button1.Text = "A) 6 cm²";
            button2.Text = "B) 7 cm²";
            button3.Text = "C) 5 cm²";
            button4.Text = "D) 12 cm²";
		}
		
		void QUESTÃO3ToolStripMenuItemClick(object sender, EventArgs e)
		{
			label1.Text = "3. Português – Interpretação de Texto";
            label2.Text = "Leia: “O sol se pôs no horizonte, tingindo o céu de laranja. O verbo “tingindo” indica:";
            button1.Text = "A) Ação passada concluída";
            button2.Text = "B) Ação contínua";
            button3.Text = "C) Ação futura";
            button4.Text = "D) Ação condicional";
		}
		
		void QUESTÃO4ToolStripMenuItemClick(object sender, EventArgs e)
		{
			label1.Text = "4. Português – Gramática";
            label2.Text = "Qual frase está correta?";
            button1.Text = "A) Eu vou à escola todos os dias.";
            button2.Text = "B) Eu vou a escola todos os dias.";
            button3.Text = "C) Eu vou à escola todos os dia.";
            button4.Text = "D) Eu vou a escola todos os dia.";
		}
		
		void QUESTÃO5ToolStripMenuItemClick(object sender, EventArgs e)
		{
			label1.Text = "5. História – Brasil Colônia";
            label2.Text = "Qual atividade econômica foi a base da economia do Brasil colonial no século XVI?";
            button1.Text = "A) Mineração";
            button2.Text = "B) Pecuária";
            button3.Text = "C) Agricultura de cana-de-açúcar";
            button4.Text = "D) Industrialização";
		}
		
		void QUESTÃO6ToolStripMenuItemClick(object sender, EventArgs e)
		{
			label1.Text = "6. História – Brasil Império";
            label2.Text = "Quem proclamou a Independência do Brasil?";
            button1.Text = "A) Dom Pedro I";
            button2.Text = "B) Tiradentes";
            button3.Text = "C) Dom João VI";
            button4.Text = "D) Marechal Deodoro";
		}
		
		void QUESTÃO7ToolStripMenuItemClick(object sender, EventArgs e)
		{
			label1.Text = "7. Geografia – Meio Ambiente";
            label2.Text = "O que é desmatamento?";
            button1.Text = "A) Plantio de árvores em áreas urbanas";
            button2.Text = "B) Corte ou remoção da vegetação natural";
            button3.Text = "C) Proteção de áreas florestais";
            button4.Text = "D) Erosão do solo natural";
		}
		
		void QUESTÃO8ToolStripMenuItemClick(object sender, EventArgs e)
		{
			label1.Text = "8. Geografia – Clima";
            label2.Text = "Qual clima é predominante no estado de São Paulo?";
            button1.Text = "A) tropical";
            button2.Text = "B) equatorial";
            button3.Text = "C) Semiárido";
            button4.Text = "D) Polar";
		}
		
		void QUESTÃO9ToolStripMenuItemClick(object sender, EventArgs e)
		{
			label1.Text = "9. Ciências – Física";
            label2.Text = "Um objeto de 2 kg é empurrado com força de 10 N. Qual a aceleração (em m/s²)?" +
            	"F=m⋅a";
            button1.Text = "A) 2";
            button2.Text = "B) 5";
            button3.Text = "C) 10";
            button4.Text = "D) 20";
		}
		
		void QUESTÃO10ToolStripMenuItemClick(object sender, EventArgs e)
		{
			label1.Text = "10. Ciências – Biologia";
            label2.Text = "Qual é a função principal dos glóbulos vermelhos?";
            button1.Text = "A) Combater infecções";
            button2.Text = "B) Transportar oxigênio";
            button3.Text = "C) Produzir hormônios";
            button4.Text = "D) Digestão de nutrientes";
			
		}
		
		void SAIRToolStripMenuItemClick(object sender, EventArgs e)
		{
			Application.Exit();
		}
		
		void Label2Click(object sender, EventArgs e)
		{
			
		}
		
		void MenuStrip2ItemClicked(object sender, ToolStripItemClickedEventArgs e)
		{
			
		}
	}
}
