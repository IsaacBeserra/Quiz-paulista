﻿/*
 * Created by SharpDevelop.
 * User: isaac JR
 * Date: 08/10/2025
 * Time: 18:44
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Drawing;
using System.Windows.Forms;

namespace trabalho
{
	/// <summary>
	/// Description of cadastrar.
	/// </summary>
	public partial class cadastrar : Form
	{
		public cadastrar()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		
		void Button2Click(object sender, EventArgs e)
		{
			if (textBox2.Text.Length >= 8)
			{
				if (21 >= textBox2.Text.Length)
				{
					MessageBox.Show("cadastro feito com sucesso");
					tela_inicial.usuario = textBox1.Text;
	        		tela_inicial.senha = textBox2.Text;
	        		Form login = new tela_inicial();
	                login.Show();
	        	    this.Hide();
				}
			}
			else if (textBox2.Text.Length < 8)
			{
				MessageBox.Show("precisa ter no minimo 8 caracteres.");
			}
			else if (textBox2.Text.Length > 21)
			{
				MessageBox.Show("não pode ter mais de 21 caracteres.");
			}
		}
		
		void Button1Click(object sender, EventArgs e)
		{
			tela_inicial.usuario = textBox1.Text;
	        tela_inicial.senha = textBox2.Text;
	        tela_inicial inicial = new tela_inicial();
	   		inicial.Show();
	   	    this.Hide();
		}
		
		void CadastrarLoad(object sender, EventArgs e)
		{
			
		}
	}
}
