﻿/*
 * Created by SharpDevelop.
 * User: isaac JR
 * Date: 19/10/2025
 * Time: 10:44
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Drawing;
using System.Windows.Forms;

namespace trabalho
{
	/// <summary>
	/// Description of splash.
	/// </summary>
	public partial class splash : Form
	{
		public splash()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
			timer1 = new Timer();
            timer1.Interval = 3000; // 3 segundos
            timer1.Tick += timer1Tick;
            timer1.Start();
        }

        void timer1Tick(object sender, EventArgs e)
        {
             // Abre o formulário principal
            timer1.Stop();
             // Abre o formulário principal
            tela_inicial telai = new tela_inicial();
            telai.Show();
            this.Hide();
        }
		
		
		void SplashLoad(object sender, EventArgs e)
		{
			
		}
	}
}
