﻿/*
 * Created by SharpDevelop.
 * User: isaac JR
 * Date: 09/10/2025
 * Time: 08:08
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Drawing;
using System.Windows.Forms;

namespace trabalho
{
	/// <summary>
	/// Description of tela_final.
	/// </summary>
	public partial class tela_final : Form
	{
		public tela_final()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
			string showponto = MainForm.ponto.ToString();

                // Mostra o valor
                label1.Text = ("parabens, você tirou: " + showponto + " pontos");
		}
        
		
		void Label1Click(object sender, EventArgs e)
		{
			
		}
	}
}
