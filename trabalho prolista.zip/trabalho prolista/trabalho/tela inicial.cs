﻿/*
 * Created by SharpDevelop.
 * User: isaac JR
 * Date: 08/10/2025
 * Time: 18:36
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Drawing;
using System.Windows.Forms;

namespace trabalho
{
	/// <summary>
	/// Description of tela_inicial.
	/// </summary>
	public partial class tela_inicial : Form
	{
		public tela_inicial()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
			
		}
		
		public static string usuario = "";
		public static string senha = "";
		
		void Button1Click(object sender, EventArgs e)
		{
			Form cadatrar = new cadastrar();
			cadatrar.Show();
			this.Hide();
		}
		
		void Button3Click(object sender, EventArgs e)
		{
			textBox1.Text = "";
			textBox2.Text = "";
		}
		
		void Button2Click(object sender, EventArgs e)
		{
			if (textBox2.Text.Length >= 8)
			{
				if (21 >= textBox2.Text.Length)
				{
					if (textBox1.Text == usuario)
					{
						if (textBox2.Text == senha)
						{
							MessageBox.Show("o login foi um sucesso.");
						    Form cadatrar = new MainForm();
			                cadatrar.Show();
			                this.Hide();
						}
						
			    		else if (usuario != textBox1.Text && senha != textBox2.Text)
			        	{
				        	MessageBox.Show("se cadastre.");
				        }
					}
					else if (usuario != textBox1.Text && senha != textBox2.Text)
			    	{
				    	MessageBox.Show("se cadastre.");
				    }
				}
				else if (usuario != textBox1.Text && senha != textBox2.Text)
				{
					MessageBox.Show("se cadastre.");
				}
			}
			else if (textBox2.Text.Length < 8)
			{
				MessageBox.Show("precisa ter no minimo 8 caracteres.");
			}
			else if (textBox2.Text.Length > 21)
			{
				MessageBox.Show("não pode ter mais de 21 caracteres.");
			}
			else if (textBox1.Text.Length < 4)
			{
				MessageBox.Show("precisa ter no minimo 4 caracteres.");
			}
			else if (textBox1.Text.Length > 21)
			{
				MessageBox.Show("não pode ter mais de 21 caracteres.");
			}
			else if (usuario != textBox1.Text && senha != textBox2.Text)
			{
				MessageBox.Show("se cadastre.");
			}
		}
		
	}
}
